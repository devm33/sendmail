To install, in Chrome, go to Window -> Extensions, then check the box to enable "Developer Mode".

Click "Load unpacked extension..." then point to the root of this directory.
